export interface Example {
  id: string;
  code: string;
  explanation: string;
}

export interface Exercise {
  id: string;
  question: string;
  type: 'multiple-choice' | 'coding' | 'short-answer';
  options?: string[];
  answer: string;
  explanation: string;
}

export interface Lesson {
  id: string;
  title: string;
  content: string;
  examples: Example[];
  exercises: Exercise[];
}

export interface Course {
  id: string;
  title: string;
  description: string;
  icon: string;
  lessons: Lesson[];
  order: number;
}

export const courses: Course[] = [
  {
    id: 'project1',
    title: 'Project 1: Shopping Cart Association Rules Mining',
    description: 'Use Apriori Algorithm to discover product relationships, generate "Users who bought A also bought B" recommendations',
    icon: 'shopping-cart',
    order: 1,
    lessons: [
      {
        id: 'association-intro',
        title: 'Association Rules Basics',
        content: `## Association Rules Mining

Association Rules is a rule-based machine learning method to discover interesting relations between variables in large databases.

### Key Metrics

1. **Support**: How frequently an itemset appears in the dataset
   \`\`\`python
   Support(X) = count(X) / total_transactions
   \`\`\`

2. **Confidence**: Probability that item Y is purchased when item X is purchased
   \`\`\`python
   Confidence(X→Y) = count(X,Y) / count(X)
   \`\`\`

3. **Lift**: How much more likely Y is purchased when X is purchased
   \`\`\`python
   Lift(X→Y) = Confidence(X→Y) / Support(Y)
   \`\`\`

### Apriori Algorithm Principle
- If an itemset is frequent, then all its subsets must also be frequent
- If an itemset is infrequent, all its supersets must be infrequent`,
        examples: [
          {
            id: 'ex1',
            code: `import pandas as pd

// Sample transaction data
transactions = [
    ["milk", "bread", "eggs"],
    ["milk", "bread"],
    ["bread", "eggs"],
    ["milk", "bread", "eggs"],
    ["bread", "eggs"]
]

// Create DataFrame
df = pd.DataFrame({
    "transaction_id": range(1, len(transactions) + 1),
    "items": transactions
})

print("=== Transaction Data ===")
print(df)
print(f"Total transactions: {len(transactions)}")`,
            explanation: 'Create and visualize transaction data'
          },
          {
            id: 'ex2',
            code: `from mlxtend.preprocessing import TransactionEncoder
from mlxtend.frequent_patterns import apriori

// Sample transactions
transactions = [
    ["milk", "bread", "eggs"],
    ["milk", "bread"],
    ["bread", "eggs"],
    ["milk", "bread", "eggs"],
    ["bread", "eggs"]
]

// Transform to one-hot encoded DataFrame
te = TransactionEncoder()
te_array = te.fit_transform(transactions)
df = pd.DataFrame(te_array, columns=te.columns_)

print("=== One-Hot Encoded Data ===")
print(df)

// Find frequent itemsets with Apriori
frequent_itemsets = apriori(df, min_support=0.4, use_colnames=True)
print("\\n=== Frequent Itemsets (support >= 0.4) ===")
print(frequent_itemsets)`,
            explanation: 'Apply Apriori algorithm to find frequent itemsets'
          }
        ],
        exercises: [
          {
            id: 'ex1',
            question: 'What is the formula for Support?',
            type: 'multiple-choice',
            options: ['count(X) / total_transactions', 'count(X,Y) / count(X)', 'Confidence / Support(Y)', 'Lift × Confidence'],
            answer: 'count(X) / total_transactions',
            explanation: 'Support measures how frequently an itemset appears in the dataset'
          },
          {
            id: 'ex2',
            question: 'If Support(A) = 0.3 and Support(B) = 0.4, what can we say?',
            type: 'multiple-choice',
            options: ['A appears in 30% of transactions', 'B appears in 40% of transactions', 'Both A and B appear together', 'A and B are negatively correlated'],
            answer: 'A appears in 30% of transactions',
            explanation: 'Support(A) indicates the percentage of transactions containing A'
          }
        ]
      }
    ]
  },
  {
    id: 'project2',
    title: 'Project 2: RFM Analysis & Value Clustering',
    description: 'Analyze user value using RFM Model, use KMeans Clustering to segment users into different groups',
    icon: 'users',
    order: 2,
    lessons: [
      {
        id: 'rfm-intro',
        title: 'RFM Model Basics',
        content: `## RFM Analysis

RFM is a customer segmentation technique based on three metrics:

- **R (Recency)**: How recently did the customer make a purchase?
- **F (Frequency)**: How often do they purchase?
- **M (Monetary)**: How much do they spend?

### RFM Segmentation Benefits
1. Identify high-value customers
2. Develop targeted marketing strategies
3. Improve customer retention rates

### Scoring Method
Each metric is scored 1-5 (5 being best):
- R5: Purchased within 1 month
- R4: 1-3 months ago
- R3: 3-6 months ago
- R2: 6-12 months ago
- R1: More than 1 year ago`,
        examples: [
          {
            id: 'ex1',
            code: `import pandas as pd
import numpy as np
from datetime import datetime, timedelta

// Create sample customer data
np.random.seed(42)
n_customers = 100

// Generate random purchase dates within last year
end_date = datetime.now()
start_date = end_date - timedelta(days=365)

data = {
    "customer_id": range(1, n_customers + 1),
    "purchase_amount": np.random.uniform(50, 5000, n_customers),
    "purchase_date": [
        start_date + timedelta(days=np.random.randint(0, 365))
        for _ in range(n_customers)
    ]
}

df = pd.DataFrame(data)
df["purchase_date"] = pd.to_datetime(df["purchase_date"])

print("=== Sample Customer Data ===")
print(df.head(10))
print(f"\\nDate range: {df['purchase_date'].min()} to {df['purchase_date'].max()}")`,
            explanation: 'Create sample customer purchase data'
          },
          {
            id: 'ex2',
            code: `import pandas as pd
import numpy as np
from datetime import datetime, timedelta

// Recreate sample data
np.random.seed(42)
end_date = datetime.now()

data = {
    "customer_id": range(1, 101),
    "purchase_amount": np.random.uniform(50, 5000, 100),
    "purchase_date": [
        end_date - timedelta(days=np.random.randint(1, 365))
        for _ in range(100)
    ]
}
df = pd.DataFrame(data)

// Calculate RFM metrics
analysis_date = end_date + timedelta(days=1)

rfm = df.groupby("customer_id").agg({
    "purchase_date": lambda x: (analysis_date - x.max()).days,
    "customer_id": "count",
    "purchase_amount": "sum"
}).reset_index()

rfm.columns = ["customer_id", "recency", "frequency", "monetary"]

print("=== RFM Metrics ===")
print(rfm.head(10))

// RFM Scoring (quintiles)
rfm["R_score"] = pd.qcut(rfm["recency"], 5, labels=[5, 4, 3, 2, 1])
rfm["F_score"] = pd.qcut(rfm["frequency"].rank(method="first"), 5, labels=[1, 2, 3, 4, 5])
rfm["M_score"] = pd.qcut(rfm["monetary"].rank(method="first"), 5, labels=[1, 2, 3, 4, 5])

print("\\n=== RFM Scores ===")
print(rfm[["customer_id", "R_score", "F_score", "M_score"]].head(10))`,
            explanation: 'Calculate RFM values and create scores'
          }
        ],
        exercises: [
          {
            id: 'ex1',
            question: 'What does R in RFM stand for?',
            type: 'multiple-choice',
            options: ['Recency (days since last purchase)', 'Frequency (purchase count)', 'Monetary (total spend)', 'Retention rate'],
            answer: 'Recency (days since last purchase)',
            explanation: 'R = Recency, the number of days since the last purchase. Lower is better.'
          },
          {
            id: 'ex2',
            question: 'In RFM scoring, what does a higher R score indicate?',
            type: 'multiple-choice',
            options: ['More recent purchase', 'Older purchase', 'Higher frequency', 'Higher spending'],
            answer: 'More recent purchase',
            explanation: 'In our scoring system, R5 = most recent, R1 = oldest'
          }
        ]
      }
    ]
  },
  {
    id: 'project3',
    title: 'Project 3: Anomaly Order Detection',
    description: 'Identify and handle anomalies in order data: null values, duplicates, outliers, and logical errors',
    icon: 'alert-circle',
    order: 3,
    lessons: [
      {
        id: 'anomaly-intro',
        title: 'Anomaly Detection Basics',
        content: `## Data Quality & Anomaly Detection

Data anomalies can significantly impact analysis results. Common types:

### 1. Missing Values (Null/NaN)
- Check: \`df.isnull().sum()\`
- Handle: Fill, interpolate, or remove

### 2. Duplicate Records
- Check: \`df.duplicated().sum()\`
- Handle: Remove with \`drop_duplicates()\`

### 3. Outliers
- Methods: Z-score, IQR (Interquartile Range)
- Z-score: |z| > 3 is outlier
- IQR: value < Q1 - 1.5×IQR or > Q3 + 1.5×IQR

### 4. Logical Errors
- Negative quantities
- Future dates
- Invalid categories`,
        examples: [
          {
            id: 'ex1',
            code: `import pandas as pd
import numpy as np

// Create sample order data with anomalies
np.random.seed(42)
n = 100

data = {
    "order_id": range(1, n + 1),
    "customer_id": np.random.randint(1, 50, n),
    "quantity": np.random.choice([1, 2, 3, -1, 100], n, p=[0.4, 0.3, 0.2, 0.05, 0.05]),
    "price": np.random.uniform(10, 1000, n),
    "order_date": pd.date_range("2024-01-01", periods=n, freq="D")
}

df = pd.DataFrame(data)

// Introduce some anomalies
df.loc[10, "quantity"] = np.nan
df.loc[20, "customer_id"] = np.nan
df.loc[5, "order_date"] = pd.NaT

print("=== Data Quality Check ===")
print("\\n--- Missing Values ---")
print(df.isnull().sum())

print("\\n--- Duplicate Rows ---")
print(f"Duplicates: {df.duplicated().sum()}")

print("\\n--- Data Types ---")
print(df.dtypes)`,
            explanation: 'Detect data quality issues in orders'
          },
          {
            id: 'ex2',
            code: `import pandas as pd
import numpy as np

// Sample data with outliers
np.random.seed(42)
data = {
    "order_id": range(1, 101),
    "amount": np.random.normal(500, 100, 100)
}
df = pd.DataFrame(data)

// Add outliers
df.loc[0, "amount"] = 5000
df.loc[1, "amount"] = 10
df.loc[2, "amount"] = 3000

print("=== Outlier Detection ===")

// Method 1: Z-score
mean = df["amount"].mean()
std = df["amount"].std()
df["z_score"] = (df["amount"] - mean) / std
print("\\nZ-score method (|z| > 3):")
outliers_z = df[abs(df["z_score"]) > 3]
print(outliers_z[["order_id", "amount", "z_score"]])

// Method 2: IQR
Q1 = df["amount"].quantile(0.25)
Q3 = df["amount"].quantile(0.75)
IQR = Q3 - Q1
lower = Q1 - 1.5 * IQR
upper = Q3 + 1.5 * IQR

print(f"\\nIQR method (bounds: {lower:.2f} - {upper:.2f}):")
outliers_iqr = df[(df["amount"] < lower) | (df["amount"] > upper)]
print(outliers_iqr[["order_id", "amount"]])`,
            explanation: 'Detect outliers using Z-score and IQR methods'
          }
        ],
        exercises: [
          {
            id: 'ex1',
            question: 'How to detect missing values in a DataFrame?',
            type: 'multiple-choice',
            options: ['df.isnull()', 'df.empty()', 'df.na()', 'df.null()'],
            answer: 'df.isnull()',
            explanation: 'isnull() returns a boolean DataFrame marking null value positions'
          },
          {
            id: 'ex2',
            question: 'In IQR method, what is considered an outlier?',
            type: 'multiple-choice',
            options: ['value < Q1-1.5×IQR or > Q3+1.5×IQR', 'value < mean - std', 'value > 2×mean', 'any negative value'],
            answer: 'value < Q1-1.5×IQR or > Q3+1.5×IQR',
            explanation: 'IQR outlier rule: below Q1-1.5×IQR or above Q3+1.5×IQR'
          }
        ]
      }
    ]
  },
  {
    id: 'project4',
    title: 'Project 4: Shopping Cart Conversion Funnel Analysis',
    description: 'Analyze user conversion funnel from browsing to purchase, identify drop-off points',
    icon: 'trending-up',
    order: 4,
    lessons: [
      {
        id: 'funnel-intro',
        title: 'Conversion Funnel Basics',
        content: `## Funnel Analysis

Funnel analysis tracks user behavior through stages:

### Typical E-commerce Funnel
1. **Visit** → Page views
2. **Browse** → Product views
3. **Add to Cart** → Cart additions
4. **Checkout** → Started checkout
5. **Purchase** → Completed order

### Key Metrics
- **Conversion Rate**: Percentage moving to next stage
- **Drop-off Rate**: Percentage leaving at each stage
- **Overall Conversion**: Visit to Purchase rate

### Formula
\`\`\`
Conversion Rate = (Users at Stage N) / (Users at Stage N-1) × 100%
\`\`\``,
        examples: [
          {
            id: 'ex1',
            code: `import pandas as pd

// Sample funnel data
funnel_data = {
    "stage": ["Visit", "Product_View", "Add_to_Cart", "Checkout", "Purchase"],
    "users": [10000, 6500, 3500, 2000, 1200]
}

df = pd.DataFrame(funnel_data)

// Calculate conversion metrics
df["next_stage_users"] = df["users"].shift(-1)
df["conversion_rate"] = (df["next_stage_users"] / df["users"] * 100).round(2)
df["drop_off"] = df["users"] - df["next_stage_users"]
df["drop_off_rate"] = (100 - df["conversion_rate"]).round(2).fillna(0)

print("=== Conversion Funnel Analysis ===")
print(df)

print("\\n=== Key Insights ===")
worst_step = df[df["drop_off_rate"] == df["drop_off_rate"].max()].iloc[0]
print(f"Highest drop-off: {worst_step['stage']} ({worst_step['drop_off_rate']}%)")
print(f"Overall conversion: {df.iloc[-1]['users']/df.iloc[0]['users']*100:.2f}%")`,
            explanation: 'Analyze conversion funnel with drop-off rates'
          }
        ],
        exercises: [
          {
            id: 'ex1',
            question: 'What is the formula for Conversion Rate?',
            type: 'multiple-choice',
            options: ['current_step / previous_step × 100', 'total_users / current_step', 'previous_step / current_step', 'drop_off / total_users'],
            answer: 'current_step / previous_step × 100',
            explanation: 'Conversion Rate = users at current stage / users at previous stage × 100%'
          },
          {
            id: 'ex2',
            question: 'If 100 users visit and 25 purchase, what is the overall conversion rate?',
            type: 'multiple-choice',
            options: ['25%', '4%', '75%', '20%'],
            answer: '25%',
            explanation: 'Overall conversion = (25/100) × 100% = 25%'
          }
        ]
      }
    ]
  },
  {
    id: 'project5',
    title: 'Project 5: Sales Trend & Seasonality Analysis',
    description: 'Analyze sales trends and seasonality, use Time Series methods to forecast future sales',
    icon: 'line-chart',
    order: 5,
    lessons: [
      {
        id: 'timeseries-intro',
        title: 'Time Series Analysis Basics',
        content: `## Time Series Analysis

Time series data has four components:
- **Trend**: Long-term direction (up/down)
- **Seasonality**: Regular patterns (daily/monthly/yearly)
- **Cyclical**: Irregular fluctuations
- **Noise**: Random variation

### Common Analysis Methods
1. **Moving Average**: Smooth out fluctuations
2. **YoY (Year-over-Year)**: Compare with same period last year
3. **MoM (Month-over-Month)**: Compare with previous month
4. **Decomposition**: Separate components

### Key Python Functions
- \`resample()\`: Aggregate by time period
- \`rolling()\`: Calculate moving statistics
- \`shift()\`: Compare with previous periods`,
        examples: [
          {
            id: 'ex1',
            code: `import pandas as pd
import numpy as np

// Create sample time series data
np.random.seed(42)
dates = pd.date_range("2023-01-01", periods=365, freq="D")

// Generate sales with trend and seasonality
trend = np.linspace(100, 200, 365)// Upward trend
seasonality = 30 * np.sin(np.arange(365) * 2 * np.pi / 365)// Yearly cycle
noise = np.random.normal(0, 10, 365)

sales = trend + seasonality + noise

df = pd.DataFrame({
    "date": dates,
    "sales": sales
})
df.set_index("date", inplace=True)

print("=== Daily Sales Data ===")
print(df.head(10))

// Resample to monthly
monthly = df.resample("ME").sum()
print("\\n=== Monthly Sales ===")
print(monthly.head(12))

// Calculate rolling average
df["rolling_7d"] = df["sales"].rolling(window=7).mean()
df["rolling_30d"] = df["sales"].rolling(window=30).mean()

print("\\n=== Moving Averages ===")
print(df[["sales", "rolling_7d", "rolling_30d"]].tail(10))`,
            explanation: 'Create and analyze time series sales data'
          },
          {
            id: 'ex2',
            code: `import pandas as pd
import numpy as np

// Create sample data
np.random.seed(42)
dates = pd.date_range("2023-01-01", periods=730, freq="D")
sales = 1000 + np.linspace(0, 500, 730) + 200 * np.sin(np.arange(730) * 2 * np.pi / 365) + np.random.normal(0, 50, 730)

df = pd.DataFrame({"date": dates, "sales": sales})
df.set_index("date", inplace=True)

// Calculate YoY and MoM growth
monthly = df.resample("ME").sum()

monthly["prev_month"] = monthly["sales"].shift(1)
monthly["mom_growth"] = ((monthly["sales"] - monthly["prev_month"]) / monthly["prev_month"] * 100).round(2)

monthly["prev_year"] = monthly["sales"].shift(12)
monthly["yoy_growth"] = ((monthly["sales"] - monthly["prev_year"]) / monthly["prev_year"] * 100).round(2)

print("=== YoY and MoM Growth ===")
print(monthly[["sales", "mom_growth", "yoy_growth"]].dropna())`,
            explanation: 'Calculate Year-over-Year and Month-over-Month growth'
          }
        ],
        exercises: [
          {
            id: 'ex1',
            question: 'What does resample("W") do in pandas?',
            type: 'multiple-choice',
            options: ['Resample by week (Weekly)', 'Resample by month', 'Resample by day', 'Resample by year'],
            answer: 'Resample by week (Weekly)',
            explanation: 'W = Weekly, aggregates data by week'
          },
          {
            id: 'ex2',
            question: 'What does a 7-day rolling average calculate?',
            type: 'multiple-choice',
            options: ['Average of last 7 days', 'Sum of last 7 days', 'Maximum of last 7 days', 'Standard deviation of last 7 days'],
            answer: 'Average of last 7 days',
            explanation: 'Rolling(window=7).mean() calculates the moving average over 7 periods'
          }
        ]
      }
    ]
  },
  {
    id: 'project6',
    title: 'Project 6: Repurchase Interval & Lifecycle Clustering',
    description: 'Analyze user repurchase patterns, build customer lifecycle and engagement decay models',
    icon: 'clock',
    order: 6,
    lessons: [
      {
        id: 'repurchase-intro',
        title: 'Customer Lifecycle Analysis',
        content: `## Customer Lifecycle & Repurchase Analysis

### Customer Lifecycle Stages
1. **Acquisition**: New customer acquisition
2. **Activation**: First purchase
3. **Retention**: Repeated purchases
4. **Revival**: Re-engagement
5. **Churn**: No recent activity

### Key Metrics
- **Repurchase Interval**: Days between consecutive purchases
- **Average Order Frequency**: Orders per time period
- **Customer Lifetime Value (CLV)**: Total revenue from customer
- **Churn Rate**: Percentage leaving

### Engagement Decay Model
Customers become less active over time. Model this with exponential decay:
\`\`\`
engagement(t) = engagement_0 × e^(-λt)
\`\`\``,
        examples: [
          {
            id: 'ex1',
            code: `import pandas as pd
import numpy as np
from datetime import timedelta

// Create sample repeat purchase data
np.random.seed(42)

orders = []
for customer_id in range(1, 6):
    n_orders = np.random.randint(3, 8)
    base_date = pd.Timestamp("2024-01-01")
    current_date = base_date
    
    for _ in range(n_orders):
        interval = np.random.randint(5, 30)// 5-30 days between purchases
        current_date = current_date + timedelta(days=interval)
        orders.append({
            "customer_id": customer_id,
            "order_date": current_date,
            "amount": np.random.uniform(50, 500)
        })

df = pd.DataFrame(orders)
print("=== Sample Orders ===")
print(df)

// Calculate repurchase intervals
df = df.sort_values(["customer_id", "order_date"])
df["next_order_date"] = df.groupby("customer_id")["order_date"].shift(-1)
df["repurchase_interval"] = (df["next_order_date"] - df["order_date"]).dt.days

print("\\n=== Repurchase Intervals ===")
print(df[["customer_id", "order_date", "repurchase_interval"]].dropna())

// Average repurchase interval per customer
avg_interval = df.groupby("customer_id")["repurchase_interval"].mean()
print("\\n=== Average Repurchase Interval per Customer ===")
print(avg_interval)`,
            explanation: 'Calculate customer repurchase intervals'
          }
        ],
        exercises: [
          {
            id: 'ex1',
            question: 'What does repurchase interval measure?',
            type: 'multiple-choice',
            options: ['Days between two purchases', 'Days since first purchase', 'Days since last purchase', 'Total days as customer'],
            answer: 'Days between two purchases',
            explanation: 'Repurchase interval is the time gap between consecutive purchases by the same customer'
          },
          {
            id: 'ex2',
            question: 'How to calculate days between consecutive purchases?',
            type: 'multiple-choice',
            options: ['groupby + diff()', 'sum() / count()', 'max() - min()', 'count() / len()'],
            answer: 'groupby + diff()',
            explanation: 'df.groupby("customer").date.diff() gives days between consecutive purchases'
          }
        ]
      }
    ]
  },
  {
    id: 'project7',
    title: 'Project 7: Sentiment Analysis & Rating Inconsistency',
    description: 'Analyze sentiment in text reviews, identify samples where ratings don\'t match sentiment',
    icon: 'message-circle',
    order: 7,
    lessons: [
      {
        id: 'sentiment-intro',
        title: 'Sentiment Analysis Basics',
        content: `## Sentiment Analysis

Sentiment analysis determines the emotional tone behind text.

### Approaches
1. **Lexicon-based**: Use predefined sentiment dictionaries
2. **Machine Learning**: Train models on labeled data
3. **Deep Learning**: Neural networks (BERT, etc.)

### Common Tools
- **SnowNLP**: Chinese text sentiment
- **TextBlob**: English text sentiment
- **VADER**: Social media sentiment

### Sentiment Score
- Positive: score > 0
- Neutral: score = 0
- Negative: score < 0

### Rating-Sentiment Mismatch
Sometimes ratings don't match text sentiment:
- High rating + Negative review = Problem indicator
- Low rating + Positive review = Quality issue`,
        examples: [
          {
            id: 'ex1',
            code: `# Simulating sentiment analysis (without external libraries)
import re

// Simple lexicon-based sentiment scoring
positive_words = ["good", "great", "excellent", "amazing", "wonderful", "love", "best", "perfect", "happy", "recommend"]
negative_words = ["bad", "terrible", "awful", "hate", "worst", "horrible", "disappointed", "poor", "never", "avoid"]

def simple_sentiment(text):
    text = text.lower()
    pos_count = sum(1 for word in positive_words if word in text)
    neg_count = sum(1 for word in negative_words if word in text)
    return pos_count - neg_count

// Sample reviews
reviews = [
    {"rating": 5, "text": "This product is amazing! Best purchase ever!"},
    {"rating": 1, "text": "Terrible quality, would never recommend."},
    {"rating": 5, "text": "Good product but shipping was slow."},
    {"rating": 2, "text": "It works okay, nothing special."},
    {"rating": 4, "text": "Great value for money, very happy!"}
]

print("=== Sentiment Analysis ===")
for review in reviews:
    sentiment = simple_sentiment(review["text"])
    sentiment_label = "Positive" if sentiment > 0 else "Negative" if sentiment < 0 else "Neutral"
    
  // Check mismatch
    expected_sentiment = "Positive" if review["rating"] >= 4 else "Negative" if review["rating"] <= 2 else "Neutral"
    mismatch = sentiment_label != expected_sentiment
    
    print(f"Rating: {review['rating']}, Sentiment: {sentiment_label} ({sentiment:+d}), Mismatch: {'⚠️ YES' if mismatch else '✓'}")`,
            explanation: 'Simple lexicon-based sentiment analysis'
          }
        ],
        exercises: [
          {
            id: 'ex1',
            question: 'What does sentiment analysis primarily measure?',
            type: 'multiple-choice',
            options: ['Emotional tone of text', 'Text length', 'Text grammar', 'Word frequency'],
            answer: 'Emotional tone of text',
            explanation: 'Sentiment analysis determines whether text is positive, negative, or neutral'
          },
          {
            id: 'ex2',
            question: 'What might a 5-star rating with negative review text indicate?',
            type: 'multiple-choice',
            options: ['Product issue with good overall rating', 'User made a mistake', 'Positive review', 'No issue'],
            answer: 'Product issue with good overall rating',
            explanation: 'Mismatch between rating and sentiment often reveals hidden issues'
          }
        ]
      }
    ]
  },
  {
    id: 'project8',
    title: 'Project 8: Shopping Cart Product Recommendation',
    description: 'Based on Collaborative Filtering Algorithm, recommend complementary products for items in cart',
    icon: 'shopping-bag',
    order: 8,
    lessons: [
      {
        id: 'collaborative-intro',
        title: 'Collaborative Filtering Recommendation',
        content: `## Collaborative Filtering

### Types
1. **User-based**: "Users like you also liked..."
2. **Item-based**: "Users who bought this also bought..."

### Cosine Similarity
Measures similarity between items:
\`\`\`
cosine(A, B) = (A · B) / (||A|| × ||B||)
\`\`\`

Range: -1 (opposite) to 1 (identical)

### Steps for Item-based CF
1. Build user-item matrix
2. Calculate item similarity
3. For target item, find similar items
4. Recommend top-N similar items`,
        examples: [
          {
            id: 'ex1',
            code: `import pandas as pd
import numpy as np
from sklearn.metrics.pairwise import cosine_similarity

// Sample user-item purchase matrix
np.random.seed(42)

users = ["user_1", "user_2", "user_3", "user_4", "user_5"]
items = ["milk", "bread", "eggs", "butter", "cheese"]

// Binary purchase data (1 = purchased, 0 = not)
data = np.array([
    [1, 1, 1, 0, 0],// user_1
    [1, 1, 0, 1, 0],// user_2
    [0, 1, 1, 1, 0],// user_3
    [1, 0, 1, 0, 1],// user_4
    [0, 0, 1, 1, 1],// user_5
])

df = pd.DataFrame(data, index=users, columns=items)
print("=== User-Item Matrix ===")
print(df)

// Calculate item-item similarity
item_similarity = cosine_similarity(df.T)
item_sim_df = pd.DataFrame(item_similarity, index=items, columns=items)

print("\\n=== Item-Item Cosine Similarity ===")
print(item_sim_df.round(3))`,
            explanation: 'Calculate item-item similarity matrix'
          },
          {
            id: 'ex2',
            code: `import pandas as pd
import numpy as np
from sklearn.metrics.pairwise import cosine_similarity

// Same data as before
users = ["user_1", "user_2", "user_3", "user_4", "user_5"]
items = ["milk", "bread", "eggs", "butter", "cheese"]
data = np.array([
    [1, 1, 1, 0, 0],
    [1, 1, 0, 1, 0],
    [0, 1, 1, 1, 0],
    [1, 0, 1, 0, 1],
    [0, 0, 1, 1, 1],
])

item_similarity = cosine_similarity(data.T)
item_sim_df = pd.DataFrame(item_similarity, index=items, columns=items)

// Recommendation function
def recommend_items(item_name, top_n=2):
    if item_name not in items:
        return f"Item '{item_name}' not found"
    
    similarities = item_sim_df[item_name].drop(item_name).sort_values(ascending=False)
    return similarities.head(top_n)

print("=== Recommendations for 'bread' ===")
recs = recommend_items("bread")
print(recs)

print("\\n=== Recommendations for 'eggs' ===")
recs = recommend_items("eggs")
print(recs)

print("\\n=== Recommendations for 'milk' ===")
recs = recommend_items("milk")
print(recs)`,
            explanation: 'Generate product recommendations based on similarity'
          }
        ],
        exercises: [
          {
            id: 'ex1',
            question: 'What is the range of Cosine Similarity?',
            type: 'multiple-choice',
            options: ['-1 to 1', '0 to 1', '0 to 100', '-100 to 100'],
            answer: '-1 to 1',
            explanation: 'Cosine similarity ranges from -1 (opposite) to 1 (identical)'
          },
          {
            id: 'ex2',
            question: 'In Item-based Collaborative Filtering, what do we calculate?',
            type: 'multiple-choice',
            options: ['Similarity between items', 'User similarity', 'Purchase count', 'Price correlation'],
            answer: 'Similarity between items',
            explanation: 'Item-based CF finds similar items based on user purchase patterns'
          }
        ]
      }
    ]
  },
  {
    id: 'project9',
    title: 'Project 9: Promotional Campaign Effectiveness Analysis',
    description: 'Analyze real promotional campaign effects using A/B Testing and Statistical Tests',
    icon: 'percent',
    order: 9,
    lessons: [
      {
        id: 'abtest-intro',
        title: 'A/B Testing Basics',
        content: `## A/B Testing

A/B testing compares two versions to determine which performs better.

### Key Concepts
- **Control Group (A)**: Original version
- **Treatment Group (B)**: Modified version
- **Random Assignment**: Equal chance for each user

### Statistical Tests
1. **t-test**: Compare means (continuous data)
2. **Chi-square test**: Compare proportions
3. **p-value**: Probability of seeing results by chance

### Interpreting Results
- **p-value < 0.05**: Statistically significant
- **Confidence Interval**: Range of plausible values
- **Effect Size**: Magnitude of difference

### Common Metrics
- Conversion rate
- Average order value
- Click-through rate
- Session duration`,
        examples: [
          {
            id: 'ex1',
            code: `import numpy as np
from scipy import stats

// Simulate A/B test data
np.random.seed(42)

// Control group: conversion rate ~ 10%
control_group = np.random.choice([0, 1], size=1000, p=[0.9, 0.1])

// Treatment group: expected improvement ~ 12%
treatment_group = np.random.choice([0, 1], size=1000, p=[0.88, 0.12])

print("=== A/B Test Results ===")
print(f"Control: {control_group.mean()*100:.2f}% conversion ({control_group.sum()}/1000)")
print(f"Treatment: {treatment_group.mean()*100:.2f}% conversion ({treatment_group.sum()}/1000)")

// Chi-square test for proportions
conversions = [control_group.sum(), treatment_group.sum()]
samples = [len(control_group), len(treatment_group)]
contingency = [[conversions[0], samples[0]-conversions[0]], 
               [conversions[1], samples[1]-conversions[1]]]

chi2, p_value, dof, expected = stats.chi2_contingency(contingency)

print(f"\\n=== Statistical Test ===")
print(f"Chi-square statistic: {chi2:.4f}")
print(f"p-value: {p_value:.4f}")
print(f"Significant (p<0.05): {'Yes ✓' if p_value < 0.05 else 'No ✗'}")`,
            explanation: 'Perform A/B test with Chi-square test'
          },
          {
            id: 'ex2',
            code: `import numpy as np
from scipy import stats

// Simulate A/B test for average order value
np.random.seed(42)

// Control group: mean = \$50, std = \$15
control = np.random.normal(50, 15, 1000)

// Treatment group: expected mean = \$55 (10% lift)
treatment = np.random.normal(55, 15, 1000)

print("=== A/B Test: Average Order Value ===")
print(f"Control: mean=\${control.mean():.2f}, std=\${control.std():.2f}")
print(f"Treatment: mean=\${treatment.mean():.2f}, std=\${treatment.std():.2f}")
print(f"Lift: {((treatment.mean()-control.mean())/control.mean()*100):.2f}%")

// Two-sample t-test
t_stat, p_value = stats.ttest_ind(treatment, control)

print(f"\\n=== Two-Sample t-Test ===")
print(f"t-statistic: {t_stat:.4f}")
print(f"p-value: {p_value:.4f}")
print(f"Significant (p<0.05): {'Yes ✓' if p_value < 0.05 else 'No ✗'}")

// Calculate 95% confidence interval for the difference
diff = treatment.mean() - control.mean()
se = np.sqrt(control.var()/len(control) + treatment.var()/len(treatment))
ci_lower = diff - 1.96 * se
ci_upper = diff + 1.96 * se
print(f"\\n95% CI for difference: [\${ci_lower:.2f}, \${ci_upper:.2f}]")`,
            explanation: 'Perform t-test for comparing means'
          }
        ],
        exercises: [
          {
            id: 'ex1',
            question: 'What does p-value < 0.05 typically mean?',
            type: 'multiple-choice',
            options: ['Statistically significant difference', 'No difference', 'Inconclusive', 'Error in calculation'],
            answer: 'Statistically significant difference',
            explanation: 'p-value < 0.05 means we reject the null hypothesis and conclude a significant difference exists'
          },
          {
            id: 'ex2',
            question: 'When should we use a t-test vs Chi-square test?',
            type: 'multiple-choice',
            options: ['t-test for means, Chi-square for proportions', 'Both are interchangeable', 't-test for proportions', 'Chi-square for means'],
            answer: 't-test for means, Chi-square for proportions',
            explanation: 't-test compares continuous variables (e.g., revenue), Chi-square compares categorical outcomes (e.g., conversion)'
          }
        ]
      }
    ]
  },
  {
    id: 'project10',
    title: 'Project 10: End-to-End Data Cleaning & User Profiling',
    description: 'Comprehensive application of skills: complete data cleaning and user profiling analysis',
    icon: 'file-report',
    order: 10,
    lessons: [
      {
        id: 'end2end-intro',
        title: 'End-to-End Data Analysis Pipeline',
        content: `## Data Analysis Pipeline

A complete data analysis project follows these stages:

### 1. Data Collection
- Import from various sources
- API calls, databases, files

### 2. Data Cleaning
- Handle missing values
- Remove duplicates
- Fix data types
- Handle outliers

### 3. Data Integration
- Merge multiple datasets
- Join tables
- Handle schema conflicts

### 4. Feature Engineering
- Create new features
- Encode categorical variables
- Scale numerical features

### 5. Modeling
- Build predictive models
- Clustering
- Classification

### 6. Reporting
- Visualizations
- Key insights
- Actionable recommendations`,
        examples: [
          {
            id: 'ex1',
            code: `import pandas as pd
import numpy as np

// Simulate raw order data with issues
np.random.seed(42)

data = {
    "order_id": range(1, 101),
    "customer_id": np.random.randint(1, 30, 100),
    "product": np.random.choice(["A", "B", "C", "D"], 100),
    "quantity": np.random.choice([1, 2, 3, -1, 100], 100, p=[0.6, 0.25, 0.1, 0.03, 0.02]),
    "price": np.random.uniform(10, 500, 100),
    "order_date": pd.date_range("2024-01-01", periods=100, freq="D")
}

raw_df = pd.DataFrame(data)

raw_df.loc[5, "quantity"] = np.nan
raw_df.loc[10, "customer_id"] = np.nan
raw_df.loc[15, "price"] = -100
raw_df = pd.concat([raw_df, raw_df.iloc[[0]]])

print("=== Raw Data Issues ===")
print(f"Total rows: {len(raw_df)}")
print(f"Missing values:\\n{raw_df.isnull().sum()}")
print(f"Negative prices: {(raw_df['price'] < 0).sum()}")
print(f"Duplicates: {raw_df.duplicated().sum()}")`,
            explanation: 'Identify data quality issues in raw data'
          },
          {
            id: 'ex2',
            code: `import pandas as pd
import numpy as np

np.random.seed(42)
data = {
    "order_id": list(range(1, 101)),
    "customer_id": np.random.randint(1, 30, 100).tolist(),
    "product": np.random.choice(["A", "B", "C", "D"], 100).tolist(),
    "quantity": np.random.choice([1, 2, 3, 99, 100], 100, p=[0.6, 0.25, 0.1, 0.03, 0.02]).tolist(),
    "price": np.random.uniform(10, 500, 100).tolist(),
    "order_date": pd.date_range("2024-01-01", periods=100, freq="D").tolist()
}

raw_df = pd.DataFrame(data)
raw_df.loc[5, "quantity"] = None
raw_df.loc[10, "customer_id"] = None
raw_df.loc[15, "price"] = -100
raw_df = pd.concat([raw_df, raw_df.iloc[[0]]])

print("=== Raw Data Issues ===")
print(f"Total rows: {len(raw_df)}")
print(f"Missing values: {raw_df.isnull().sum().sum()}")
print(f"Negative prices: {(raw_df['price'] < 0).sum()}")

df = raw_df.drop_duplicates()
df = df.dropna(subset=["customer_id"])
df["quantity"] = df["quantity"].fillna(df["quantity"].median())
df = df[df["price"] > 0]
df["quantity"] = df["quantity"].abs()
df["total_amount"] = df["quantity"] * df["price"]

print("\\n=== After Cleaning ===")
print(f"Rows: {len(df)}")
print(df.describe())`,
            explanation: 'Complete data cleaning workflow'
          }
        ],
        exercises: [
          {
            id: 'ex1',
            question: 'What is typically the first step in a data analysis pipeline?',
            type: 'multiple-choice',
            options: ['Data Collection', 'Data Cleaning', 'Modeling', 'Visualization'],
            answer: 'Data Collection',
            explanation: 'Analysis starts with collecting raw data from various sources'
          },
          {
            id: 'ex2',
            question: 'What should be done with negative prices in cleaning?',
            type: 'multiple-choice',
            options: ['Remove or fix to positive values', 'Keep them as is', 'Convert to NaN only', 'Multiply by -1'],
            answer: 'Remove or fix to positive values',
            explanation: 'Negative prices are invalid and should be removed or corrected'
          }
        ]
      }
    ]
  }
];
